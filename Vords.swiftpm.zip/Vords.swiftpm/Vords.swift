import SwiftUI
import SwiftData




@main
struct Vords: App {
    var body: some Scene {
        WindowGroup {
            ContainerView()
        }       

    }
}
